/**
 * 
 */
package NHSsystem;

/**
 * @author chrismcclune
 *
 */
public class Nurse extends Person {

	/**
	 * Default constructor
	 */
	public Nurse() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor with arguments
	 * @param title
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param postcode
	 * @param contactNumber
	 */
	public Nurse(String title, String firstName, String lastName,
			String street, String city, String postcode, String contactNumber) {
		super(title, firstName, lastName, street, city, postcode, contactNumber);
		// TODO Auto-generated constructor stub
	}

}
