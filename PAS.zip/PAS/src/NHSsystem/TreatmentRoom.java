/**
 * 
 */
package NHSsystem;

/**
 * @author chrismcclune
 *
 */
public class TreatmentRoom {

	/**
	 * 
	 */
	public TreatmentRoom() {
		// TODO Auto-generated constructor stub
	}

}
