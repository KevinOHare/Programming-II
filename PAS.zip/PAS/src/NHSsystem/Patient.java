/**
 * 
 */
package NHSsystem;

/**
 * @author chrismcclune
 *
 */
public class Patient extends Person {

	/**
	 * Default constructor
	 */
	public Patient() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor with arguments
	 * @param title
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param postcode
	 * @param contactNumber
	 */
	public Patient(String title, String firstName, String lastName,
			String street, String city, String postcode, String contactNumber) {
		super(title, firstName, lastName, street, city, postcode, contactNumber);
		// TODO Auto-generated constructor stub
	}

}
